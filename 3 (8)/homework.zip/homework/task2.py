#o'zgaruvchi e'lon qilinmoqda
#va unga boshlang'ich qiymat berilmoqda
even_numbers = 0

#sikl boshlanmoqda
#toki o'zgaruvchi qiymati 101 gacha borguncha, shart bajariladi
while even_numbers < 101:
    #o'zgaruvchining joriy qiymati chop etilmoqda
    print(even_numbers)
    #o'zgaruvchining qiymati ikkiga oshirilmoqda
    even_numbers += 2