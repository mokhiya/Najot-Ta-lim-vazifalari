#Foydalanuvchi sizga mm da masofani kiritadi vazifangiz uni km, m, dm, sm, mm da ko'rsatish 

distance = float(input("Please, enter a distance in mm: "))

#converting mm numbers to sm, dm, m and km
sm = distance / 10
dm = distance / 100
m = distance / 1000
km = distance / 1000000

print(f"Your number in >>> \nmm: {distance} \nsm: {sm} \ndm: {dm} \nm: {m} \nkm: {km}")

