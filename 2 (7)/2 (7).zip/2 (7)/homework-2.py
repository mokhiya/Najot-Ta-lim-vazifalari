#2-vazifa
name = input("Ismingizni kiriting: ")
print(name[0])