#3-vazifa
print("afsuski, 3-vazifaning sharti 1-vazifa bilan bir xil ekan :(")