#1-vazifa
number = input("2 yoki undan ortiq xonali son kiriting: ")
if len(number)>=3:
    print (number[0]+number[-1])




