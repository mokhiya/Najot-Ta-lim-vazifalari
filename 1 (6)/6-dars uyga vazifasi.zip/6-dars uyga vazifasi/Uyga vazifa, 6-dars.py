#1-vazifa
fathers_age = 48
mothers_fav_meal = "manti"
mothers_year= 1975
bestfr_name = "Ozoda"
hated_cartoon = "Maugli"
best_fplayer = "Messi"
fav_thing_Mars = "rang"
future_travel= "Germaniya"
future_cars = 2
fav_car = "BMW x7"

#2-vazifa
print(type(fathers_age))
print(type(mothers_fav_meal))
print(type(mothers_year))
print(type(bestfr_name))
print(type(hated_cartoon))
print(type(best_fplayer))
print(type(fav_thing_Mars))
print(type(future_travel))
print(type(future_cars))
print(type(fav_car))

#3-vazifa
num1 = 33
num1= str(num1)
print(num1)

text = "Mars mening uyim"
text = bool(text)
print(text)

num2 = 90.90 
num2= str(num2)
print(num2)

num3 = "8899"
num3= int(num3)
print(num3)

num4 = 9090 
num4 = str(num4)
print(num4)

f1 = 2012
f1 = float(f1)
print(f1)

num5 = 1212.12
num5 = int(num5)
print(num5)

text2 = "Xayr"
text2 = str(text2)
print(text2)

m = 5  # m uchun ixtiyoriy qiymat berildi
complex_number = complex(2*m + 3, 0)
print(complex_number)

num6 = 12.2
num6 = int(num6)
print(num6)

num7 = 33.3
num7 = int(num7)
print(num7)