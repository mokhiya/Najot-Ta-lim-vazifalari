import hashlib
from jsonmanager import JsonManager

user_book_manager = JsonManager("user_book.json")

class User:
    """This class initializes a user with full_name, email, password, and default attributes."""
    def __init__(self, full_name, email, password):
        self.full_name = full_name
        self.email = email
        self.password = password
        self.is_login = False
        self.read_books = []  # List to store books the user has read
        self.exchanged_books = []  # List to store exchanged books


    def check_password(self, confirmed_password):
        """This method checks if the confirmed_password matches the user's password."""
        return confirmed_password == self.password


    @staticmethod
    def hash_password(user_password):
        """This method hashes the user's password using SHA-256."""
        return hashlib.sha256(user_password.encode()).hexdigest()


    def add_read_book(self, book):
        """Add a book to the user's list of read books."""
        self.read_books.append(book)
        return "Book added to your read list!"


    def add_exchanged_book(self, book):
        """Add a book to the user's list of exchanged books."""
        self.exchanged_books.append(book)
        return "Book added to your exchanged list!"