from userclass import User, user_book_manager
from jsonmanager import JsonManager


def register_user():
    """
    This function is used to register a user.
    """
    full_name = input("Enter your full name: ").title().strip()
    
    while True:  # Checking if user enters a valid email
        user_email = input("Enter your email: ").strip()
        if user_email.endswith('@gmail.com') or user_email.endswith('@mail.ru') or user_email.endswith('@yahoo.com'):
            break
        else:
            print("Invalid input, enter an email again!")

    user_password = input("Enter your password: ")
    confirm_user_password = input("Confirm your password: ")

    user = User(full_name=full_name, email=user_email, password=user_password)
    if not user.check_password(confirmed_password=confirm_user_password):
        print("Sorry, your passwords did not match, please, start the registration again!")
        return register_user()
    else:
        user.password = User.hash_password(user_password=user_password)
        print("Congratulations, you have registered successfully!\n")

        user_book_manager.add_data(data=user.__dict__)
        return display_main_menu()


def login_user():
    """This function is used to log in an existing user by verifying email and password."""
    global current_user
    
    while True:  # Checking if user enters a valid email
        user_email = input("Enter your email: ").strip()
        if user_email.endswith('@gmail.com') or user_email.endswith('@mail.ru') or user_email.endswith('@yahoo.com'):
            break
        else:
            print("Invalid input, enter an email again!")

    user_password = input("Enter your password: ")
    hashed_password = User.hash_password(user_password=user_password)

    all_users = user_book_manager.read()
    for user_data in all_users:
        if 'email' in user_data and 'password' in user_data:
            if user_data['email'] == user_email and user_data['password'] == hashed_password:
                user = User(full_name=user_data['full_name'], email=user_data['email'], password=user_data['password'])
                user.is_login = True
                current_user = user
                print("You have logged in successfully!")
                return display_user_menu(current_user)
    print("User does not exist or invalid password")
    return display_main_menu()


def logout_all_users():
    """
    This function is used to log out all logged-in users by updating their is_login status in the JSON file.
    """
    all_users = user_book_manager.read()
    for user in all_users:
        user['is_login'] = False
    user_book_manager.write(all_users)
    return display_main_menu()


def add_read_book():
    """Function to add a book that the user has read."""
    if current_user and current_user.is_login:
        title = input("Enter the book title: ").strip()
        author = input("Enter the book author: ").strip()
        book = {"title": title, "author": author, "added_by": current_user.email}
        current_user.add_read_book(book)
        user_book_manager.add_data({"type": "book", **book})
        print(f"Book '{title}' added successfully.")
    else:
        print("You need to log in to add a book.")
    return display_user_menu(current_user)


def display_available_books():
    """Function to display available books and allow users to choose one to view or exchange."""
    all_books = []
    all_data = user_book_manager.read()
    for data in all_data:
        if data.get('type') == 'book':
            all_books.append(data)

    if all_books:
        print("Available Books:")
        if all_books:
            print("Available Books:")
            i = 1
            for book in all_books:
                print(f"{i}. {book['title']} by {book['author']} (Added by {book['added_by']})")
                i += 1
        try:        
            choice = int(input("Choose a book to view details or type 0 to go back: "))
            if 0 < choice <= len(all_books):
                book = all_books[choice - 1]
                print(f"Title: {book['title']}\nAuthor: {book['author']}\nAdded by: {book['added_by']}")
                exchange_choice = input("Would you like to exchange this book? (y/n): ").strip().lower()
                if exchange_choice == 'y':
                    current_user.add_exchanged_book(book)
                    print("Book added to your exchanged list.")
                    index = user_book_manager.read().index(book)
                    user_book_manager.delete_data(index)
                elif exchange_choice == 'n':
                    pass
            elif choice == 0:
                return display_user_menu(current_user)
            else:
                print("Invalid choice.")
                return display_available_books()
        except ValueError:
            print("Enter a number, please!")
    else:
        print("No available books.")
    return display_user_menu(current_user)

def display_user_menu(current_user):
    """This function is used to display a menu for the logged-in user."""
    while True:
        text = """
        1. Add a book to my read list.
        2. View available books.
        3. View my read books.
        4. View my exchanged books.
        5. Log out.
        6. Exit
        """
        print(text)

        user_input = input("Choose a number from the menu: ").strip()

        if user_input == "1":
            add_read_book()
        elif user_input == "2":
            display_available_books()
        elif user_input == "3":
            if current_user.read_books:
                for book in current_user.read_books:
                    print(f"Title: {book['title']}, Author: {book['author']}")
            else:
                print("You have no read books.")
        elif user_input == "4":
            if current_user.exchanged_books:
                for book in current_user.exchanged_books:
                    print(f"Title: {book['title']}, Author: {book['author']}")
            else:
                print("You have no exchanged books.")
        elif user_input == "5":
            current_user.is_login = False
            print("You have been logged out.")
            return display_main_menu()
        elif user_input == "6":
            print("Exiting the program. See you!")
            return display_main_menu()
        else:
            print("Invalid input, please try again.")


def display_main_menu():
    """This function is used to show a main manu to a user"""
    text = """
    
    1. Register.
    2. Login.
    3. Exit. """

    print(text)

    user_input = int(input("Choose a number from menu: "))

    if user_input == 1:
        register_user()
    elif user_input == 2:
        login_user()
    elif user_input == 3:
        yes_no_input = input("Would you like to quit? (y/n): ")
        if yes_no_input.lower() == "y":
            print("You quitted the program. See you!")
        else:
            return display_main_menu()
    else:
        print("Choose a proper number! ")
        return display_main_menu()
    
if __name__ == "__main__":
    logout_all_users()